//
//  Rtc555Config.swift
//  Rtc555Sdk
//
//  Created by Girish on 05/03/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation

/**
* The ``Rtc555Config`` class contains mandatory parameters which is used for RtcConnection
*/
public class Rtc555Config{

    /**
    * phonenumber of participant for rtcconnection
    */
    public var phoneNumber : String = ""

    /**
    * token for rtcconnection
    */
    public var token : String = ""

    /**
    * routingid of participant for rtcconnection
    */
    public var routingId : String = ""

    /**
    * rtcserverurl for rtcconnection
    */
    public var url : String = ""
    /**
    * domain for rtcconnection
    */
    public var domain : String = ""
    
    /**
    * enableReconnect for reconnection incase of network switch
    */
    public var enableReconnect : Bool = false
    /**
    * rtcserverurl for rtcconnection
    */
    public var notificationManagerUrl : String = ""
    
}
