//
//  Rtc555Ntm.swift
//  Rtc555Sdk
//
//  Created by Girish on 08/05/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation

/** These are the different Protocoltype
*/
public enum ProtocolMode:String{
    /** When the protocol type is xmpp
    */
    case xmpp = "xmpp"
    /** When the protocol type is apns
    */
    case apns = "apns"

}

/** These are the different topics for noitification subscription
*/
public enum Topic:String{
    /** When the protocol type is xmpp
    */
    case pstn = "pstn"
    /** When the protocol type is apns
    */
    case video = "video"

}

public struct Subscription{

    /**
    * device token for notification
    */
    public var deviceToken:String

    /**
    * protocol for notification
    */
    public var protocolType:ProtocolMode

    /**
    * token for notification
    */
    public var topic:Topic
    /**
    * apntopic for notification
    */
    public var apnTopic:String
    
    public init(){
        self.deviceToken = ""
        self.apnTopic = ""
        self.topic = Topic.pstn
        self.protocolType = ProtocolMode.apns
    }
    
}

public class Rtc555Ntm: NSObject {
    override init(){}
    public static func createSubscriptions(subscriptions subscriptionsData:[Subscription],appdomain appDomain:String,rtcNtmDelegate ntmDelegate:Rtc555NtmDelegate){
        RtcReactBridge.sharedInstance.ntmDelegateMap["createSubscriptions"] = ntmDelegate
        var args = [[String: String]]()
        for susbscription in subscriptionsData {
            var config : [String : String] = [:]
            config["deviceToken"] = susbscription.deviceToken
            config["protocol"] = susbscription.protocolType.rawValue
            config["topic"] = susbscription.topic.rawValue
            config["apntopic"] = susbscription.apnTopic
            args.append(config)
        }
        
        let jsonData = try! JSONSerialization.data(withJSONObject: args as Any, options: [])
        let subscriptionData = String(data: jsonData, encoding: .utf8)!
    
        RtcReactBridge.sharedInstance.callMethod("createSubscriptions","Rtc555Ntm",[subscriptionData,appDomain])
    }
    
    public static func deleteSubscription(subscriberId subscriberid:String,topic Topic:Topic,appdomain appDomain:String,rtcNtmDelegate ntmDelegate:Rtc555NtmDelegate){
        RtcReactBridge.sharedInstance.ntmDelegateMap["deleteSubscription"] = ntmDelegate
        let args = [subscriberid,Topic.rawValue,appDomain] as [Any]
        RtcReactBridge.sharedInstance.callMethod("deleteSubscription","Rtc555Ntm",args)
        
    }
    
    public static func deleteAllSubscriptions(subscriberId subscriberid:String,rtcNtmDelegate ntmDelegate:Rtc555NtmDelegate){
           RtcReactBridge.sharedInstance.ntmDelegateMap["deleteSubscription"] = ntmDelegate
           let args = [subscriberid] as [Any]
           RtcReactBridge.sharedInstance.callMethod("deleteAllSubscriptions","Rtc555Ntm",args)
           
       }
}

/**
* Rtc555NtmDelegate is used to send callbacks for notification
*/
public protocol Rtc555NtmDelegate {
    /**
    * onSubscriptionSuccess is called when subscription is success
    */
    func onSubscriptionSuccess(subscriptions subscriptionInfo:[Any])
    /**
      onSubscriptionFailure is called with error info
     - Parameters:
          - error: contains error info
    */
    func onSubscriptionFailure(error errorInfo:Error)
    /**
      onSubscriptionDeleted is called with topic and subscriberid
     - Parameters:
          - topic: topic which is deleted
          - subscriberid: subscribtion id
    */
    
    func onSubscriptionDeleted(topic Topic:NSString,subscriberId subscriberid:NSString)
    /**
      onSubscriptionDeleted is called with subscriberid
     - Parameters:
          - subscriberid: subscribtion id
    */
    
    func onSubscriberDeleted(subscriberId subscriberid:NSString)
    /**
      onSubscriptionDeletionFailure is called with error info
     - Parameters:
          - error: contains error info
    */
    
    func onSubscriptionDeletionFailure(error errorInfo:Error)
}


