#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "RNInCallManager.h"

FOUNDATION_EXPORT double ReactNativeIncallManagerVersionNumber;
FOUNDATION_EXPORT const unsigned char ReactNativeIncallManagerVersionString[];

