
#import <WebRTC/RTCMediaStreamTrack.h>

#import "VideoCaptureController.h"

@interface RTCMediaStreamTrack (React)

@property (strong, nonatomic) VideoCaptureController *videoCaptureController;

@end
