//
//  RtcRenderer.swift
//  RtcReactSdk
//
//  Created by Girish on 08/01/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation
import UIKit
import React

/**
* The ``RtcRenderer`` class is used to creat a renderer for stream and to add stream to renderer
*/
public class RtcRenderer: NSObject {
    /**
    * Object of RctRootView
    */
    public var videoView : RCTRootView!
    override init(){
        super.init()
    }
    /**
     This method is used to initialize renderer
      - Parameters:
           - frameSize: view bounds which is required to initalize renderer
    */
    public init?(frameSize : CGRect){
        super.init()
        RtcReactBridge.sharedInstance.createBridge()
        videoView =   RtcReactBridge.sharedInstance.loadView(frame: frameSize)
    }
    /**
     This method is used to add stream to renderer
      - Parameters:
           - stream: object of type RtcStream which will be added to renderer
    */
    public func addStream(streamId:String){
        var stream = RtcStream()
        if(!streamId.isEmpty){
           if(Rtc555Video.streamDict[streamId] != nil){
               stream = Rtc555Video.streamDict[streamId]!
           }
        }

        let jsonData = try! JSONSerialization.data(withJSONObject: stream.mediaStream as Any, options: [])
        let streamData = String(data: jsonData, encoding: .utf8)!
        videoView.appProperties = ["stream":streamData]
    }
}
